 <?php
 echo "
 <div class=\"container well about\" id=\"about\">
    <div class=\"row\">
      <div class=\"col-xs-6 col-sm-6 col-md-6 col-lg-7\">
        <div class=\"row\">
          <div class=\"col-sm-4 col-md-4 col-lg-4  col-xs-6\">
            <div>
              <h1 style=\" position:relative;float:right;\">Tor<strong>Q</strong> <br> </h1>
            </div>
          </div>
          
        </div><h5 style=\"position:relative;left:220px;\"></h5>
      </div>
      <div class=\"col-xs-6 col-sm-6 col-md-6 col-lg-5\"> 
        <address style=\"position:relative;top:20px;left:30px;\">
        <a style=\"color:white;\" href=\"about.php\">About us</a><br>
        <a style=\"color:white;\" href=\"disclaimer.php\">Disclaimer</a><br>
<a style=\"color:white;\" href=\"https://fb.com/thetyko\">Follow us on facebook!</a><br>
        
      </address>
        <address>
        <strong class=\"bold-heading\"></strong><br>
        </address>
        </div>
    </div>
	<footer class=\"text-center\">
  		<div class=\"container\" id=\"contact\">
    		<div class=\"row\">
      			<div class=\"col-xs-12\">
        			<p class=\"foot-text\">TYKO &copy 2016</p>
                </div>
      		</div>
    	</div>
   	</footer>
  </div>";
  
  ?>
